import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';


import { GlobalComponent } from 'src/app/global-component';
//import { User } from '../models/auth.models';
import { Observable } from 'rxjs';
const API_URL = GlobalComponent.API_URL+'chauffeur/';

@Injectable({ providedIn: 'root' })
export class ChauffeurService {

    constructor(private http: HttpClient) { }
    /***
     * Get All User
     */
	 
	 
	
   
	
	getChauffeurs(): Observable<any[]> {
    return this.http.get<any[]>(API_URL + 'liste');
  }

  getchauffeurparstatut(chauffeurdata :any): Observable<any[]> {
    return this.http.post<any[]>(API_URL+'liste/statut',chauffeurdata);
  }
// Create a new client
createChauffeur(vehiculeData: any): Observable<any> {
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
  return this.http.post<any>(API_URL + 'create', vehiculeData, { headers });
}

// Update an existing client
updateChauffeur(id: number, chauffeurData: any): Observable<any> {
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  console.log(chauffeurData);
 
  return this.http.put<any>(API_URL + 'update/'+id, chauffeurData, { headers });
}



    /***
     * Facked User Register
     */
   
}
