export interface ListJsModel {
  id: any;
  nom: string;
  prenom: string;
  adresse: string;
  telephone: string;
  statut: string;


}

export interface paginationModel {
  id: any;
  nom: string;
  prenom: string;
  adresse: string;
  telephone: string;
  statut: string;
}
